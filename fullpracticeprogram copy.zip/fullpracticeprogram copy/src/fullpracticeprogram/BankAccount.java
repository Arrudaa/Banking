package fullpracticeprogram;

//this is the superclass
public class BankAccount {
//#protected
//+public
//-private
	//declared both variables
	public String OwnerName;
	public int accountBalance;
	//made my constructor
	public BankAccount(String ownerName, int accountBalance) {
		
		OwnerName = ownerName;
		this.accountBalance = accountBalance;
	}
	
	//methods that will help pass values
	public void deposit(int d) {
		System.out.println("You have successfully depposted " + d + " ");
	}

	public void withdraw(int w) {
		System.out.println("You have successfully withdrawn " + w + " ");
	}
}
