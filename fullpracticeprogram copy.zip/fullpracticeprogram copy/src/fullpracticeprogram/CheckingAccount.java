package fullpracticeprogram;

//subclass to bankaccount
public class CheckingAccount extends BankAccount {
	
	//new variable that is particular to checking account
	int annualInterestFee;
	
	public CheckingAccount(String ownerName, int accountBalance, int annualInterestFee) {
		super(ownerName, accountBalance);
		this.annualInterestFee = annualInterestFee;
	}

	//unique method
	public void annualInterestFee() {
		System.out.println("The annual interest fee for our bank is 1%");
	}
}
