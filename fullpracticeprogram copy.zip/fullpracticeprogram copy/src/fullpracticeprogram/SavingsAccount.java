package fullpracticeprogram;
//subclass to bankaccount
public class SavingsAccount extends BankAccount {
	//unique to variable to savings
	public int annualInterestRate;
	
	public SavingsAccount(String ownerName, int accountBalance, int annualInterestRate) {
		super(ownerName, accountBalance);
		this.annualInterestRate = annualInterestRate;
	}

	//unique method of savings account
	public void annualInterestRate() {
		System.out.println("The annual interest rate for our bank is 2%");
		
	}
}
