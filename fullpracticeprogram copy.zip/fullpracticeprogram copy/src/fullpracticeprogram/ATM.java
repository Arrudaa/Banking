package fullpracticeprogram;

public class ATM {

	public static void main(String[] args) {
		
		BankAccount acc = new BankAccount("Sally", 123456);
		SavingsAccount sav = new SavingsAccount("Sally", 123456, 5);
		CheckingAccount chec = new CheckingAccount("Sally", 123456, 1);
		System.out.println("Welcome to the bank: " + sav.OwnerName + " " + sav.accountBalance);
		sav.deposit(100);
		sav.withdraw(50);
		chec.annualInterestFee();
		sav.annualInterestRate();

	}

}
